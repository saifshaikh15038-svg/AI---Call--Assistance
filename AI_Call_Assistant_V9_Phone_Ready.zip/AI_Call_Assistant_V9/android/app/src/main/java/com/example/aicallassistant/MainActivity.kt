package com.example.aicallassistant

import android.Manifest
import android.app.Activity
import android.os.Bundle
import android.content.pm.PackageManager
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var urlInput: EditText
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32,48,32,32) }
        val title = TextView(this).apply { text = "AI Call Assistant V9"; textSize = 26f; gravity = Gravity.CENTER }
        val note = TextView(this).apply { text = "V9 phone test client\nEnter your deployed HTTPS server URL."; textSize = 16f; setPadding(0,24,0,24) }
        urlInput = EditText(this).apply { hint = "https://your-server.example.com"; singleLine = true }
        val button = Button(this).apply { text = "Test server connection"; setOnClickListener { testServer() } }
        status = TextView(this).apply { text = "Not tested"; textSize = 16f; setPadding(0,24,0,0) }
        layout.addView(title); layout.addView(note); layout.addView(urlInput); layout.addView(button); layout.addView(status)
        setContentView(layout)
        if (android.os.Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 100)
        }
    }

    private fun testServer() {
        val base = urlInput.text.toString().trim().trimEnd('/')
        if (base.isEmpty()) { status.text = "Enter an HTTPS server URL."; return }
        status.text = "Testing..."
        thread {
            try {
                val conn = URL("$base/health").openConnection() as HttpURLConnection
                conn.requestMethod = "GET"; conn.connectTimeout = 8000; conn.readTimeout = 8000
                val code = conn.responseCode
                val body = (if (code in 200..399) conn.inputStream else conn.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
                runOnUiThread { status.text = "HTTP $code\n$body" }
                conn.disconnect()
            } catch (e: Exception) { runOnUiThread { status.text = "Connection failed: ${e.message}" } }
        }
    }
}
