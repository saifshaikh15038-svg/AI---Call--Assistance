import http from 'node:http';
import { URL } from 'node:url';
import { WebSocketServer } from 'ws';

const PORT = Number(process.env.PORT || 8080);
const PUBLIC_BASE_URL = (process.env.PUBLIC_BASE_URL || '').replace(/\/$/, '');

function json(res, code, data) {
  res.writeHead(code, {'content-type':'application/json; charset=utf-8'});
  res.end(JSON.stringify(data));
}

const server = http.createServer((req, res) => {
  const u = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  if (req.method === 'GET' && u.pathname === '/health') {
    return json(res, 200, {
      ok: true,
      version: '9.0.0',
      openaiConfigured: Boolean(process.env.OPENAI_API_KEY),
      twilioConfigured: Boolean(process.env.TWILIO_ACCOUNT_SID && process.env.TWILIO_AUTH_TOKEN),
      publicBaseUrlConfigured: Boolean(PUBLIC_BASE_URL)
    });
  }
  if (req.method === 'POST' && u.pathname === '/twilio/voice') {
    if (!PUBLIC_BASE_URL) return json(res, 500, {error:'PUBLIC_BASE_URL is not configured'});
    const host = new URL(PUBLIC_BASE_URL).host;
    const xml = `<?xml version="1.0" encoding="UTF-8"?><Response><Connect><Stream url="wss://${host}/twilio/media"/></Connect></Response>`;
    res.writeHead(200, {'content-type':'text/xml; charset=utf-8'}); res.end(xml); return;
  }
  json(res, 404, {error:'not found'});
});

const wss = new WebSocketServer({ noServer: true });
server.on('upgrade', (req, socket, head) => {
  const u = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  if (u.pathname !== '/twilio/media') { socket.destroy(); return; }
  wss.handleUpgrade(req, socket, head, ws => wss.emit('connection', ws, req));
});
wss.on('connection', ws => {
  ws.on('message', () => {});
});
server.listen(PORT, () => console.log(`AI Call Assistant V9 listening on ${PORT}`));
