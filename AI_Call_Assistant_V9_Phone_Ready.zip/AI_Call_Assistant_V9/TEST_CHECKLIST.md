# V9 test checklist

- [ ] GitHub repository created
- [ ] Actions workflow starts
- [ ] APK build succeeds
- [ ] APK artifact downloads
- [ ] APK installs on phone
- [ ] Microphone permission works
- [ ] HTTPS server `/health` returns HTTP 200
- [ ] Android app connects to `/health`
- [ ] Telephony provider webhook reaches `/twilio/voice`
- [ ] Provider media WebSocket connects
- [ ] AI backend is configured
- [ ] Controlled test call completed
- [ ] AI audio is heard by caller
- [ ] Multiple conversation turns work

Do not claim the public-number AI call is verified until the controlled call actually passes.
