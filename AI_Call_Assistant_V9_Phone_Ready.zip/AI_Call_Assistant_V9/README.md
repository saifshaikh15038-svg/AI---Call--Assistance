# AI Call Assistant V9

Phone-first Android test client plus a Node.js server scaffold.

## Build the APK from your phone
1. Upload this repository to GitHub.
2. Open **Actions**.
3. Select **Build Android APK**.
4. Tap **Run workflow**.
5. Wait for the green check.
6. Download the **AI-Call-Assistant-V9-debug** artifact.
7. Extract `app-debug.apk` and install it on Android.

## Important
This V9 Android app is a test client; it does not directly intercept ordinary SIM-call audio. The real telephone AI path requires a supported telephony provider, public HTTPS/WSS server, and correctly configured AI backend.

Never commit real API keys or provider credentials to GitHub.
